#CS106S Section: Chatbot for locating SNAP Retailers

from datetime import datetime
import googlemaps

def introMessage():
    return "Welcome to the SNAP Retailer Chatbot.  This program will help you find the nearest grocery stores that accept SNAP"

#imports data on SNAP retailers from a csv file
#stores info in a 2D array with the following format:
#storeData = [[store1_name, store1_addr, store1_city, store1_zip], [store2_name, store2_addr, store2_city, tore2_zip],...]
#for example, storeData[0] would have length 4 and would look like [Azaal Market, 200 Leavenworth St.,San Francisco, 94102]
def loadData(filename):
    storeData = []
    with open(filename) as file:
        for line in file:
            storeData.append(line.rstrip().rsplit(","))
    return storeData

def botBegin(storeData):
#get the user's current location
    while True:
        user_addr = raw_input("\nWhat's the address you're currently at? Make sure to include the zip code. Or press enter to quit. \n")
        #if the user pressed enter, quit
        if user_addr == "":
            return

        #isolate the zip code
        #for now, I'm assuming the user put in a correct address, will assume the zip code is the last word
        zip = user_addr.rsplit(None, 1)[-1]

        print "Finding nearby stores..."
        ordered = []
        for store in storeData:
            addrstring = str(store[1] + ", " + store[2] + ", " + store[3])
            ordered.append((store, getExactDistance(user_addr, addrstring)))

        ordered = sorted(ordered, key=lambda x: x[1])

        print("The nearest stores are... ")
        for store, dist in ordered:
            print(store[0] + ": " + store[1] + ", " + store[2] + ", " + store[3] + " is " + str(dist) + " meters away.")

#takes two strings as addresses and returns the distance between the addresses in meters
def getExactDistance(address1, address2):
    gmaps = googlemaps.Client(key='AIzaSyD5hfkVB3NFPeauvzTwbk6R4TJ--5fKF2U')
    now = datetime.now()
    directions_result = gmaps.distance_matrix(address1,
    address2,
    mode="driving",
    departure_time=now)
    distance = directions_result["rows"][0]["elements"][0]["distance"]["value"]
    return distance

storeData = loadData("snap-retailers.csv")
introMessage()
botBegin(storeData)
