#this is a simple program to play a game of madlibs

def fillStory():
	story_text = "Come (verb) at WALMART, where you`ll receive (adjective) discounts on all of your favorite brand name (plural noun). Our (adjective) and (verb ending in \"ING \") associates are there to (verb) you (number) hours a day. Here you will find (adjective) prices on the (plural noun) you need. (plural noun)es for the moms, (plural noun) for the kids and all the (plural noun) for the grandparents. So come on down to your (adjective) WALMART where the (plural noun) come first."
	num_blanks = 15
	curr_index = 0
	for i in range(1,15):
		replace_start = story_text.find("(")
		replace_end = story_text.find(")")
		prompt = story_text[replace_start:replace_end + 1]
		input = raw_input(prompt + ": ")
		story_text = story_text[0:replace_start] + input + story_text[replace_end + 1: len(story_text)]
		#curr_index = replace_end + 1
	print(story_text)

print("Welcome to Mad Libs! Let's get started\n")
print("Enter random words based on the following prompts \n")
fillStory()