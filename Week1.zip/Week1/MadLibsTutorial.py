#this is a simple program to play a game of madlibs

def fillStory():
	story_text = "Come (verb) at WALMART, where you`ll receive (adjective) discounts on all of" +\
	" your favorite brand name (plural noun). Our (adjective) and (verb ending in \"ING \")" + \
	" associates are there to (verb) you (number) hours a day. Here you will find (adjective)" + \
	" prices on the (plural noun) you need. (plural noun)es for the moms, (plural noun) for" + \
	" the kids and all the (plural noun) for the grandparents. So come on down to" + \
	" your (adjective) WALMART where the (plural noun) come first."
	num_blanks = 15
	curr_index = 0
	for i in range(1,15):
		#fill this part in with your own code!
		#You should find the next blank, ask the user for their input,
		#and then replace the placeholder with the user's input
		continue
	print(story_text)

print("Welcome to Mad Libs! Let's get started\n")
print("Enter random words based on the following prompts \n")
fillStory()