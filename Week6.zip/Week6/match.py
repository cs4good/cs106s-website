# CareerVillage.org collective intelligence workshop
# Stanford University CS + Social Good 
# Feb 15th, 2017
# Presenter: Jared Chung, Founder at CareerVillage.org
# Contact: jared@careervillage.org
# Built in Python 2.7

########################################################################################
# Download the data (You don't need Python for this part)                              #
########################################################################################
# To begin, you will need to get the CSV files from this Dropbox folder...
# https://www.dropbox.com/sh/7jtmcqyqmj6ripx/AABOGvfSmNBuNFWXe81IC_mNa?dl=0
# Copy these three CSV files into the folder where you have this .py file


########################################################################################
# Run these commands in python to get data out of the CSVs and into Python lists       #
########################################################################################

from datetime import datetime
import csv
import os
from ast import literal_eval

raw_question_data = csv.DictReader(open('cv_questions.csv','rU'))
question_list = []
for row in raw_question_data:
    question_list.append(row)

raw_answer_data = csv.DictReader(open('cv_answers.csv','rU'))
answer_list = []
for row in raw_answer_data:
    answer_list.append(row)

raw_user_data = csv.DictReader(open('cv_users.csv','rU'))
user_list = []
for row in raw_user_data:
    user_list.append(row)

# For convenience, we'll create a list of the actual matches.
correct_list = []
for answer in answer_list:
    match = (answer['id_of_question_being_answered'],answer['author.id'])
    if match not in correct_list: # Sometimes people answer questions twice
        correct_list.append(match)

########################################################################################
# Here are examples of how to access the data in these lists                           #
########################################################################################
def slice_and_dice_decimals(string):
    if '.' in string:
        decimalIndex = string.find('.')
        return string[:decimalIndex]
    return string

question_list[0] # The first question in the question list
question_list[1] # The second question in the question list
question_list[2] # The second question in the question list
question_list[0]['id'] # The first question's id
question_list[0]['title'] # The first question's title (usually the question in 1 sentence)
question_list[0]['body'] # The first question's body (user explanation or context for question)
question_list[0]['tagname_list'].split(' ') # The first question's tags (they are separated by spaces in the csv file, so splitting on ' ' results in a list of tags)
question_list[0]['author.id'] # The first question's author's id
question_list[0]['added_at'] # Timestamp when first question asked AS STRING
datetime.strptime(slice_and_dice_decimals(question_list[0]['added_at']), '%Y-%m-%d %H:%M:%S') # Timestamp when first question asked AS PYTHON DATETIME OBJECT

answer_list[0] # The first answer in the answer list
answer_list[1] # The second answer in the answer list
answer_list[2] # The second answer in the answer list
answer_list[0]['id'] # The first answer's id
answer_list[0]['id_of_question_being_answered'] # The id of the question the first answer is answering
answer_list[0]['body'] # The first answer's body (the actual advice content)
answer_list[0]['author.id'] # The first answer's author's id
answer_list[0]['score'] # The number of upvotes on the first answer
answer_list[0]['added_at'] # Timestamp of first answer's answer date AS STRING
datetime.strptime(slice_and_dice_decimals(answer_list[0]['added_at']), '%Y-%m-%d %H:%M:%S') # Timestamp of first answer's answer date AS PYTHON DATETIME OBJECT

user_list[0] # The first user in the user list
user_list[1] # The second user in the user list
user_list[2] # The second user in the user list
user_list[0]['id'] # The first user's id
user_list[0]['account_type'] # The first user's account type (P = Professional)
user_list[0]['date_joined'] # Timestamp when first user joined AS A STRING
datetime.strptime(slice_and_dice_decimals(user_list[0]['date_joined']), '%Y-%m-%d %H:%M:%S') # Timestamp when first user joined AS A PYTHON DATETIME OBJECT
user_list[0]['headline'] # The first user's 1-line self-intro
user_list[0]['industry'] # 1 or 2 words with the first user's industry
user_list[0]['location'] # Write-in location data
user_list[0]['answer_count_total'] # The first user's answer count
user_list[0]['karma_points'] # The first user's karma total
user_list[0]['notification_setting'] # What the first user set (can be blank)
user_list[0]['topics_followed'].split(' ') # List of tags followed by the first user in the list.

########################################################################################
# Your awesome matching algorithm goes here...
# my_clever_predictions returns a list of tuples.
# Each tuple consists of two elements: a question_id and the user_id of a user who could potentially answer the question.
# If you'd like to assign multiple users to the same question, you will have to create a new tuple for each question-user pair.
########################################################################################

def my_clever_predictions():
    predicted_list = []
    # 
    # 
    # 
    # your great idea goes here
    # 
    # 
    #
    return predicted_list

# You want your predicted_list to have the following format:
# predicted_list = [
#     ('7412','3611'),
#     ('10556','6778'),
#     ('1081','59')
#     ]
# Where the first number is the question_id and the second number is the author.id

########################################################################################
# Now we calculate our F-Measure (aka F1 score https://en.wikipedia.org/wiki/F1_score) #
########################################################################################

# We gave you a list called correct_list which has every real question-to-user match. 
# Let's assume you have a list of retrieved matches (your predictions for which 
# questions should be sent to which users). 
def calculate_f_score(correct_list,predicted_list):
    total_matched = len(correct_list)
    total_predicted = len(predicted_list)
    correctly_predicted = len(set(correct_list).intersection(predicted_list))
    # Calculate (and print) the f-measure
    precision = float(correctly_predicted) / float(total_predicted) # Calculate precision
    recall = float(correctly_predicted) / float(total_matched) # Calculate recall
    if correctly_predicted > 0:
        f1 = 2 * ( precision * recall) / float(precision + recall)
    else:
        f1 = 0.0
    print("precision: %s" % precision)
    print("recall: %s" % recall)
    print("f1: %s" % f1)

# To run the function that both predicts matches and evaluates F score, do this:
calculate_f_score(correct_list,my_clever_predictions())
