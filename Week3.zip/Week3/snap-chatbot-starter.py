#CS106S Section: Chatbot for locating SNAP Retailers

from datetime import datetime
import googlemaps

#EDIT THIS FUNCTION
def introMessage():
	#print a welcome message to the user that gives them information about the service
    print("Hello! Please fill me out.")
        
#imports data on SNAP retailers from a csv file
#stores info in a 2D array with the following format:
#storeData = [[store1_name, store1_addr, store1_city, store1_zip], [store2_name, store2_addr, store2_city, tore2_zip],...]
#for example, storeData[0] would have length 4 and would look like [Azaal Market, 200 Leavenworth St.,San Francisco, 94102]
#DO NOT EDIT
def loadData(filename):
    storeData = []
    with open(filename) as file:
        for line in file:
            storeData.append(line.rstrip().rsplit(","))
    return storeData

#prints the bot's messages adn reads user input
#uses an address input by the user to return nearest stores
#EDIT THIS FUNCTION
def botBegin(storeData):
#get the user's current location
    while True:
        #print a message from the chatbot and get the user's address using raw_input
        #You should include some way for the user to quit out of the program

        #once you have the address, isolate the zip code
        #is it ok to assume that the user put in their address in the correct format?
        #you decide!

        print("Finding nearby stores...")
        #using the getExactDistance function, find the nearest stores
        #hint: you can sort an array like last week!

#takes two strings as addresses and returns the distance between the addresses in meters
#DO NOT EDIT
def getExactDistance(address1, address2):
        gmaps = googlemaps.Client(key='AIzaSyD5hfkVB3NFPeauvzTwbk6R4TJ--5fKF2U')
        now = datetime.now()
        directions_result = gmaps.distance_matrix(address1,
                                     address2,
                                     mode="driving",
                                     departure_time=now)
        distance = directions_result["rows"][0]["elements"][0]["distance"]["value"]
        return distance

storeData = loadData("snap-retailers.csv")
introMessage()
botBegin(storeData)
